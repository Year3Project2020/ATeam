﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ATeam.Models
{
    public class ATeamContext : DbContext
    {
        public ATeamContext (DbContextOptions<ATeamContext> options)
            : base(options)
        {
        }

        public DbSet<ATeam.Models.PatientInput> PatientInput { get; set; }
    }
}
